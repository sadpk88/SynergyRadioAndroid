# Synergy Radio — Android starter project

This is a starter Android Studio project for the Synergy Radio app, using Kotlin, Jetpack Compose and AndroidX Media3.

## Open and run
1. Install the current stable Android Studio.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `SynergyRadioAndroid` folder.
4. Allow Gradle sync to finish; install the Android SDK requested by the project if prompted.
5. Connect an Android phone with USB debugging enabled or create an emulator, then press **Run**.

Stream configured in `app/src/main/java/com/synergy/radio/MainActivity.kt`:
`https://fire.doscast.com:8080/stream`

## Important prototype limitations
- This is an initial prototype. Playback is currently owned by the Activity and may stop when the app is closed or the process is killed. The manifest service entry is only a placeholder; implement a concrete MediaSessionService plus MediaController integration and test background playback before release.
- Verify the stream URL and TLS certificate on real devices before release.
- The favorite button is a UI prototype; persistence and separate tabs are not implemented yet.
- The app icon, adaptive icon, splash screen, privacy policy, store listing, screenshots and signed release bundle still need to be prepared.
- Before Play Store submission, target API 36 or higher (the current Play requirement as of August 31, 2026), and review current Google Play policies and complete the Data safety section accurately.
- Never publish private credentials or stream admin URLs in the app.

## Build a test APK
Use Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
For Google Play, generate a signed **Android App Bundle (.aab)** using **Build > Generate Signed Bundle / APK > Android App Bundle**.

This project is a starting point, not yet a production-ready Play Store release.
