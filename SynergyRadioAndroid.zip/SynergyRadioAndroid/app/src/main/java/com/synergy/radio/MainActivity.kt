package com.synergy.radio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Navy = Color(0xFF030719)
private val Blue = Color(0xFF087BFF)
private val Cyan = Color(0xFF00C8FF)
private val Purple = Color(0xFFB15CFF)
private const val STREAM_URL = "https://fire.doscast.com:8080/stream"

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(STREAM_URL))
            prepare()
        }
        setContent {
            var playing by remember { mutableStateOf(false) }
            var favorite by remember { mutableStateOf(false) }
            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }
            RadioScreen(
                playing = playing,
                favorite = favorite,
                onFavorite = { favorite = !favorite },
                onToggle = {
                    if (player.isPlaying) player.pause()
                    else {
                        if (player.mediaItemCount == 0) player.setMediaItem(MediaItem.fromUri(STREAM_URL))
                        player.prepare()
                        player.play()
                    }
                }
            )
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
private fun RadioScreen(
    playing: Boolean,
    favorite: Boolean,
    onFavorite: () -> Unit,
    onToggle: () -> Unit
) {
    val gradient = Brush.linearGradient(listOf(Blue, Purple, Cyan))
    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF050B2B), Navy, Color(0xFF01030C))))
                .padding(horizontal = 22.dp, vertical = 18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✦", fontSize = 34.sp, color = Cyan, fontWeight = FontWeight.Black)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SYNERGY", fontSize = 27.sp, color = Color.White, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                        Text("—  R A D I O  —", fontSize = 12.sp, color = Cyan, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = onFavorite) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = "Favoris", tint = if (favorite) Purple else Color.White)
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(230.dp)
                            .background(Brush.radialGradient(listOf(Color(0x553C68FF), Color(0x223F16A8), Color.Transparent)), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦", fontSize = 190.sp, color = Color.Transparent,
                            modifier = Modifier.background(gradient, CircleShape))
                        Surface(
                            modifier = Modifier.size(118.dp),
                            shape = CircleShape,
                            color = Navy,
                            border = androidx.compose.foundation.BorderStroke(3.dp, gradient)
                        ) {
                            IconButton(onClick = onToggle) {
                                Icon(
                                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (playing) "Pause" else "Lecture",
                                    tint = Color.White,
                                    modifier = Modifier.size(58.dp)
                                )
                            }
                        }
                    }
                    Text(if (playing) "EN DIRECT" else "PRÊT À ÉCOUTER", color = Cyan, letterSpacing = 4.sp, fontSize = 12.sp)
                    Text("Synergy Radio", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("Good Music  •  Better Vibes", color = Color(0xFF9CB8FF), fontSize = 15.sp, letterSpacing = 1.sp)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1538)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF203F9B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Blue, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Radio, contentDescription = null, tint = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Live Stream", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Synergy Radio", color = Color(0xFF9CB8FF))
                        }
                        Icon(Icons.Default.VolumeUp, contentDescription = "Audio", tint = Cyan, modifier = Modifier.size(30.dp))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem(Icons.Default.Home, "Accueil", true)
                    NavItem(Icons.Default.Radio, "Radio", false)
                    NavItem(Icons.Default.FavoriteBorder, "Favoris", false)
                    NavItem(Icons.Default.Settings, "Réglages", false)
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = label, tint = if (selected) Cyan else Color(0xFF929AC8), modifier = Modifier.size(25.dp))
        Text(label, color = if (selected) Cyan else Color(0xFF929AC8), fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}
